#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_


typedef double REAL;
typedef int    INT;



#endif

