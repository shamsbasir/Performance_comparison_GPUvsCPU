#ifndef _DEFINITSIONS_H_
#define _DEFINITIONS_H_


#define YELLOW "\033[01;33m"
#define GREEN "\033[32m"
#define CYAN "\033[36m"
#define RESET "\033[0m"
#define OUTOFF  0// 0 to turn off, 1 to turn on





#endif
