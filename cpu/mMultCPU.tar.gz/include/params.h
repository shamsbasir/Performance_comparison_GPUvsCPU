#ifndef _PARAMS_H_
#define _PARAMS_H_




#include "timer.h"
#include <cblas.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>





#endif
